/**
 * 
 */
/**
 * @author Laboratorio C10
 *
 */
module Projeto_filme {
	requires java.sql;
	requires java.desktop;
}