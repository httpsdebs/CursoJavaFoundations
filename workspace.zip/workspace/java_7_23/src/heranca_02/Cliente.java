package heranca_02;

public class Cliente {

	public static void main(String[] args) {
		PessoaFisica cliente = new PessoaFisica();
		
		cliente.nome ="Cliente";
		
		
	}

}
