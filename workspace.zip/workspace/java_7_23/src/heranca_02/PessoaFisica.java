package heranca_02;

public class PessoaFisica extends Pessoa {
	String genero;
	String cor;
	String idade;
	String cpf;
	String rg;

}
