package heranca_02;

public class Pessoa {
	String nome;
	String telefone;
	String endereco;
	String email;
	

}
