package heranca_02;

public class PessoaJuridica {
	String cnpj;
	String ie;

}
