package exercicios;

import javax.swing.JOptionPane;

public class exerc_04 {

	public static void main(String[] args) {
	
	int nota_P1;
	int nota_P2;
	int nota_trab;
	int total;
	
	
	nota_P1=Integer.parseInt(JOptionPane.showInputDialog("Digite sua nota na prova 1 "));
	
	
	
	
	

	
	
		
	
	
		
	
	
	
	
	
	
	
	
	
	
		
		
		
		
		
		

	}

}
