package calcPOO;

public class Calculadora {

	public static void main(String[] args) {
		Calculo calculadora = new Calculo();
		
		calculadora.setValor_01(5);
		calculadora.setValor_02(10);

		System.out.println(calculadora.getValor_01());
		System.out.println(calculadora.getValor_02());

	}

}
