package calcPOO;

public class Calculo {
	
	private double valor_01;
	private double valor_02;
	private double total;
	public double getValor_01() {
		return valor_01;
	}
	public void setValor_01(double valor_01) {
		this.valor_01 = valor_01;
	}
	public double getValor_02() {
		return valor_02;
	}
	public void setValor_02(double valor_02) {
		this.valor_02 = valor_02;
	}
	public double getTotal() {
		return total;
	}
	public void setTotal(double total) {
		this.total = total;
	}

	
}
