package Metodos_02;

public class SemParametros {
	
	String frase;
	
	public static void testar() {
		System.out.println("Eu sou um método estático");
	}
	
	public static void testarOutro() {
		System.out.println("Eu sou um método normal");
	}
	
	public void semParametro() {
		System.out.println(frase);
	}
	
	public void semParametro(String frase) {
		System.out.println(frase);
	}

}
