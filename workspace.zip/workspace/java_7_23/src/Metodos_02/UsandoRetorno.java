package Metodos_02;

import java.util.Scanner;

public class UsandoRetorno {

	public static void main(String[] args) {
		double valor_01, valor_02;
		

		Scanner ler = new Scanner(System.in);
		System.out.println("Digite um valor: ");
		valor_01= ler.nextDouble();
		System.out.println("Digite outro valor");
		valor_02=ler.nextDouble();
		
		ComRetornoSemParametro retorno = new ComRetornoSemParametro();
		
		
	}

}
