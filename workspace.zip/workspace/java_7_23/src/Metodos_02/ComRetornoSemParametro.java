package Metodos_02;

public class ComRetornoSemParametro {

	public double dividir(double valor_01,valor_02) {
		double total;
		total = valor_01/valor_02;
		
		return total;
	}
}
