package Metodos_02;

public class OutraClasse {

	public static void main(String[] args) {
		String frase = "estou aqui";
		SemParametros parametro = new SemParametros();
		SemParametros frase1 = new SemParametros();

		
	/*	
		SemParametros.testar();
		testarAqui();
		SemParametros.testarOutro();
		*/
		frase1.semParametro(frase);
	}
	
	public static void testarAqui() {
		System.out.println("o");

	}

}
