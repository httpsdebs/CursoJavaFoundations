/**
 * 
 */
/**
 * @author Laboratorio C10
 *
 */
module Java_7_23 {
	requires java.desktop;
}