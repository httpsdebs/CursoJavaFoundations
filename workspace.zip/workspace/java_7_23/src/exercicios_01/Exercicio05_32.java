package exercicios_01;

import javax.swing.JOptionPane;

public class Exercicio05_32 {

	public static void main(String[] args) {

	String numero;
	
	numero=JOptionPane.showInputDialog("digite um numero");
	JOptionPane.showMessageDialog(null,"você digitou:"+numero);
	
	
	
	
		
		
		
		
	}

}
