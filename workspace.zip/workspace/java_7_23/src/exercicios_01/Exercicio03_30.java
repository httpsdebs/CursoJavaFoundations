package exercicios_01;

import java.util.Scanner;

import javax.swing.JOptionPane;

public class Exercicio03_30 {

	public static void main(String[] args) {
//definindo variaveis
   
	int valor_01;
	int valor_02;
	int total;
	
//Definindo o Metodo de Entrada de Dados
	
  Scanner ler= new Scanner(System.in);
	
//Entrada de Dados[

System.out.println("Digite um valor");
valor_01=ler.nextInt();

System.out.println("Digite outro valor");
valor_02=ler.nextInt();


//Processando os dados
total=valor_01*valor_02;

//Saída de dados do Processamento

System.out.println("O valor total é"+total);


//Teste a multiplicação 28*43





		
		
		
		
		
	}

}
