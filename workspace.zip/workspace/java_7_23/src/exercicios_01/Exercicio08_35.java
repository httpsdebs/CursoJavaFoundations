package exercicios_01;

import javax.swing.JOptionPane;

public class Exercicio08_35 {

	public static void main(String[] args) {

		String nome;
		String endereço;
		String numero;
		
		nome=JOptionPane.showInputDialog("Qual o seu nome?");
		
		endereço=JOptionPane.showInputDialog("Qual o seu endereço?");
		
		numero=JOptionPane.showInputDialog("Qual o seu número");
		
		
		
		
	}

}
