package exercicios_01;

import java.util.Scanner;

public class Exercicio06_33 {

	public static void main(String[] args) {

		int valor_1;
		int valor_2;
		
		
		Scanner ler = new Scanner(System.in);
		
		System.out.println("Digite um valor");
		valor_1=ler.nextInt();

		System.out.println("Digite outro valor");
		valor_2=ler.nextInt();
		
		System.out.println("valor 1: "+ valor_1);
		System.out.println("valor 2: "+ valor_2);
		
	
		

		
	
		
		
	 
	 
		
		
		 
		
		

	}

}
