package exercicios_01;

import java.util.Scanner;

public class Exercicio11_38 {

	public static void main(String[] args) {

		//variaveis
int valor_01;
double valor;

//metodo
		
Scanner ler = new Scanner(System.in);

//Entrada de Dados
System.out.println("Digite um valor:");
valor_01= ler.nextInt();

//processamento
valor=(valor_01)/3;

//Saída
System.out.println("Um terço desse numero:"+valor);

		
		
		
		
	}

}
