package exercicios_01;

import java.util.Scanner;

public class Exercicio09_36 {

	public static void main(String[] args) {

	
	 
	 
	 
	 
   
		
		
		
		
		
		
	}

}
