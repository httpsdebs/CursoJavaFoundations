package exercicios_01;

import java.util.Scanner;

public class Exercicio10_37 {

	public static void main(String[] args) {

		//variaveis
		 int valor_01;
		 int valor_02;
		 int valor;
		//metodo de entrada
		 Scanner ler= new Scanner(System.in);
		 
		 //entrada de dados
		 System.out.println("Digite um valor");
		 valor_01= ler.nextInt();
		 
		 System.out.println("Digite um valor");
		 valor_02= ler.nextInt();
		 
		 //processamento
		 valor=(valor_01*valor_02);
		 
		 System.out.println("O resultado é:"+valor);
		 
		 
		 
		
		
		
		
		
		
		
		
	}

}
