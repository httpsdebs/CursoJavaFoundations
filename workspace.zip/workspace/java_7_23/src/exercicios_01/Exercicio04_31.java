package exercicios_01;

import java.util.Scanner;

public class Exercicio04_31 {

	public static void main(String[] args) {
	//variaveis 	
		double notas_01;
		double notas_02;
		double notas_03;
		double media;
		
		//metodo de entrada
		Scanner ler= new Scanner(System.in);
		
		
		//entrada de dados
		System.out.println("digite um valor");
		notas_01=ler.nextDouble();
		
		System.out.println("digite um valor");
		notas_02=ler.nextDouble();
		
		System.out.println("digite um valor");
		notas_03=ler.nextDouble();
		
		//Processando os dados
		
		media=(notas_01+notas_02+notas_03)/3;
		
		//saída de dados 
		
		System.out.println("A média é:"+media);
		
		
		
		
		
		

		
	
		
	
		
		
		
		
		
		
		
		
		

	}

}
