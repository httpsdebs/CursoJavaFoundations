package exercicios_01;

public class Exercicio01_28 {

	public static void main(String[] args) {

	System.out.println("É PRECISO FAZER TODOS OS ALGORITMOS PARA APRENDER");
	}

}
