package exercicios_01;

import java.util.Scanner;

public class Exercicio07_34 {

	public static void main(String[] args) {
	// variaveis 
	int valor_01;
	int antecessor;
	int sucessor;
	
	//metodo de entrada de dados
	Scanner ler= new Scanner(System.in);
	
	//entrada de dados 
	System.out.println("Digite um numero");
	valor_01= ler.nextInt();
	
	
	//Processamento de Dados
	antecessor=(valor_01)-1;
	sucessor=(valor_01)+1;
	
	//Saída de dados 
	System.out.println("O antecessor é:"+antecessor);
	System.out.println("O sucessor é:"+sucessor);
	
	
	

	
	
	


	
	

	}

}
