package java_7_23;

public class Aula01_B {

	public static void main(String[] args) {
		Aula01_A oi = new Aula01_A();
		
		System.out.println("Olá Mundo");
		oi.abrirPorta();
	}

}
