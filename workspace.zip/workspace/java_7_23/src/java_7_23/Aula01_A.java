package java_7_23;

public class Aula01_A {
	
	public void abrirPorta() {

	System.out.println("Seja Bem Vindo ao mundo Java!");
	}
}
