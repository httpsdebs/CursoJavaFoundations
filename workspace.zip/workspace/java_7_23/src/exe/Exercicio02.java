package exe;

import javax.swing.JOptionPane;

public class Exercicio02 {

	public static void main(String[] args) {
    int nivel;
    nivel=Integer.parseInt(JOptionPane.showInputDialog("Digite o nível da mensalidade "));
    
    if(nivel==1);{
    nivel_01(); 
    
    }if(nivel == 2) {
    	nivel_02();
   
    }if(nivel==3);{
    nivel_03();
    
    
    
    }
    	    		
	}
    
	

	public static void nivel_01() {
	int data=Integer.parseInt(JOptionPane.showInputDialog("Digite a data de pagamento:"));
	if(data==1) {
	    double desconto=(51.50*15)/100;
	    double total=51.50-desconto;
	    JOptionPane.showMessageDialog(null, "Total a pagar:"+total);
	    
	}else if(data>1 && data <=5) {
		double desconto = (51.50*10)/100;
		double total = 51.50-desconto;
		JOptionPane.showMessageDialog(null, "Total a pagar:"+total);
		
	}else if(data>5 && data<=10) {
		double desconto = (51.50*3.89)/100;
		double total = 51.50-desconto;
		JOptionPane.showMessageDialog(null, "Total a Pagar:"+total);
		
	}
	
	}


public static void nivel_02(){
	int data =Integer.parseInt(JOptionPane.showInputDialog("Digite a data de pagamento:"));
	if(data==1) {
		double desconto=(65*15)/100;
		double total=65-desconto;
		JOptionPane.showMessageDialog(null, "Total a pagar:"+total);
	}else if(data>1 && data <=5) {
		double desconto=(65*10)/100;
		double total = 65-desconto;
		JOptionPane.showMessageDialog(null, "Total a pagar:"+total);
	}else if(data>5 && data<=10) {
		double desconto=(65*3.89)/100;
		double total= 65-desconto;
		JOptionPane.showMessageDialog(null, "Total a Pagar:"+total);
		
		
	}
	}
	


public static void nivel_03() {
int data =Integer.parseInt(JOptionPane.showInputDialog("Digite a data de pagamento:"));
if(data==1) {
	double desconto=(80*15)/100;
	double total=80-desconto;
	JOptionPane.showMessageDialog(null, "Total a pagar:"+total);
}else if(data>1 && data <=5) {
	double desconto=(80*10)/100;
	double total = 80-desconto;
	JOptionPane.showMessageDialog(null, "Total a pagar:"+total);
}else if(data>5 && data<=10) {
	double desconto=(80*3.89)/100;
	double total= 80-desconto;
	JOptionPane.showMessageDialog(null, "Total a Pagar:"+total);
	
}
}
}


