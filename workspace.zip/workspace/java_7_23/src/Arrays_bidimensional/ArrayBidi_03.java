package Arrays_bidimensional;

public class ArrayBidi_03 {

	public static void main(String[] args) {
		String [][]pessoas = {
				{"João", "25","Masculino","São Paulo"},
				{"Maria","30","Feminino","Rio de Janeiro"},
				{"Pedro","22","Masculino","Belo Horizonte"},
				{"Ana","28","Feminino","Curitiba"}	
		};
		
		for (int i = 0; i < pessoas.length; i++) {
			
			System.out.println("Nome: "+pessoas[i][0]);
			System.out.println("Idade: "+pessoas[i][1]);
			System.out.println("Gênero: "+pessoas[i][2]);
			System.out.println("Cidade: "+pessoas[i][3]);
			
		}
	}

}
