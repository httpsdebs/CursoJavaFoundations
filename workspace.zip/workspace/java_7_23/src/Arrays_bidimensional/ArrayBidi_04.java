package Arrays_bidimensional;

import java.util.Scanner;

public class ArrayBidi_04 {

	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
		
		double[][]matriz = new double [3][4];
		
		System.out.println("Digite os valores da matriz 3x4");
		
		for (int i =0;i < 3; i++) {
			for (int j =0;j < 4; j++) {
				System.out.println("Digite o valor da posição["+i+"]["+j+"]");
				
				
			}
		}
		
		for(int i =0;i < 3; i++) {
			
		}
	}

}
