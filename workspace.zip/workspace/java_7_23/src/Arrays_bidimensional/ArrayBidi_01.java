package Arrays_bidimensional;

import java.util.Random;

public class ArrayBidi_01 {

	public static void main(String[] args) {

		public static void main(String[] args) {
			int [][]matriz = new int [3][3];
			Random random = new Random;
			
			for (int i = 0; i < matriz.length; i++) {
				for (int j = 0; j < matriz.length; j++) {
					System.out.println(matriz[i][j] + "-");
				}
			}
		
	}

}
