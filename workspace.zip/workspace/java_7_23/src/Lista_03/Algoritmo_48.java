package Lista_03;

public class Algoritmo_48 {

	public static void main(String[] args) {
		// Antes de o racionamento de energia ser decretado,
		//quase ninguém falava em quilowatts; mas, agora, todos 
		//incorporaram essa palavra em seu vocabulário. Sabendo-se
		//que 100 quilowatts de energia custa um sétimo do salário-mínimo,
		//fazer um algoritmo que receba o valor do salário-mínimo e a 
		//quantidade de quilowatts gasta por uma residência e calcule.
		//Imprima:
		//o valor em reais de cada quilowatt
		//o valor em reais a ser pago
		//o novo valor a ser pago por essa residência com
		//um desconto de 10%.
		
		
		

	}

}
