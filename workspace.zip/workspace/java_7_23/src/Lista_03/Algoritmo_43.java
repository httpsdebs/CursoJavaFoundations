package Lista_03;

public class Algoritmo_43 {

	public static void main(String[] args) {
		// Entrar com um número e imprimir o logaritmo
		//desse número na base 10.

	}

}
