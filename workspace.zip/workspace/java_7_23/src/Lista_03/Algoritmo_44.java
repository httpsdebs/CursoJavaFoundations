package Lista_03;

public class Algoritmo_44 {

	public static void main(String[] args) {
		// Entrar com o número e a base em que se deseja
		//calcular o logaritmo desse número e imprimi-lo.

	}

}
