package Lista_03;

public class Algoritmo_45 {

	public static void main(String[] args) {
		// Entrar com um número e imprimir a seguinte saída:
		//número:
		//quadrado:
		//raiz quadrada:


	}

}
