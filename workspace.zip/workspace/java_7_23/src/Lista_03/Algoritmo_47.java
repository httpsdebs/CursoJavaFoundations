package Lista_03;

public class Algoritmo_47 {

	public static void main(String[] args) {
		// Entrar com um número no formato CDU e imprimir
		//invertido: UDC. (Exemplo:123, sairá 321.) O número
		//deverá ser armazenado em outra variável antes de ser impresso.

	}

}
