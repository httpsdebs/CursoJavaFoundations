package Lista_03;

public class Algoritmo_46 {

	public static void main(String[] args) {
		// Fazer um algoritmo que possa entrar com o saldo
		//de uma aplicação e imprima o novo saldo, considerando
		//o reajuste de 1%.

	}

}
