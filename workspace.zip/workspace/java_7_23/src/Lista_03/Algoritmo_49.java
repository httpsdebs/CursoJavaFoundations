package Lista_03;

public class Algoritmo_49 {

	public static void main(String[] args) {
		//Entrar com um nome e imprimir:
		//todo nome:
		//primeiro caractere:
		//último caractere:
		//do primeiro até o terceiro:
		//quarto caractere:
		//todos menos o primeiro:
		//os dois últimos:
		
		
		

	}

}
