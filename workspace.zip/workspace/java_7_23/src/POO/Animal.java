package POO;

public class Animal {
	//o que tenho
	String especie;
	String cor;
	double tamanho;
	int peso;
	String genero;
	String raca;
	String habitat;
	
	//o que faço
	public void comer() {
		
	}
	
	public void correr() {
		
	}
	
	public void brincar() {
		
	}
	
	public void nadar() {
		
	}
	
	public void cacar() {
		
	}
	
	public void emitirSom() {
		
	}
	
	
	
	
	
}
