package POO;

public class UsaTelevisao {

	public static void main(String[] args) {
		//instancia da classe televisao
		Televisao tv = new Televisao();
		
		//atribuição de valores
		tv.canal = 150;
		tv.volume = 3;
		
		//chamando os metodos
		tv.aumentarVolume();
		tv.diminuirVolume();
		tv.trocarCanal(10);
		tv.mostrar();
		
		
	}

}
