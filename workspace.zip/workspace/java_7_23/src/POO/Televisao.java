package POO;

import javax.swing.JOptionPane;

public class Televisao {
	
	public int volume;
	public int canal;
	
	public void aumentarVolume() {
		volume++;
	}
	
	public void diminuirVolume() {
		volume--;
	}

	public void trocarCanal(int c) {
		canal=c;
	}
	
	public void mostrar() {
		JOptionPane.showMessageDialog(null, "Volume: " + volume + "\nCanal: " + canal);
	}
	
}
