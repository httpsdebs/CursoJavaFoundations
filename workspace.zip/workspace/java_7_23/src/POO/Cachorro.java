package POO;

import javax.swing.JOptionPane;

public class Cachorro {

	public static void main(String[] args) {
		///////======instanciando objeto=======///////
		
	Animal cachorro = new Animal();
	Animal gato = new Animal();
	Animal passaro = new Animal();

	
	cachorro.raca = "SRD";
	cachorro.especie= "Mamífero";
	cachorro.tamanho = 0.80;
	
	
	gato.raca ="Angora" ;
	gato.especie = "Mamífero";
	gato.tamanho = 0.4;
	
	passaro.raca ="Bem-te-vi" ;
	passaro.especie = "Ovíparo";
	passaro.tamanho = 0.2;
	
	JOptionPane.showMessageDialog(null, "Raça do cão: "+cachorro.raca 
			+"\nEspecie: "+ cachorro.especie +"\nTamanho: "+cachorro.tamanho);
	
	JOptionPane.showMessageDialog(null, "Raça do gato: "+gato.raca 
			+"\nEspecie: "+ gato.especie +"\nTamanho: "+gato.tamanho);

	JOptionPane.showMessageDialog(null, "Raça do pássaro: "+passaro.raca 
			+"\nEspecie: "+ passaro.especie +"\nTamanho: "+passaro.tamanho);

			
		
		
		
	}

}
