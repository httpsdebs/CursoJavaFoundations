package heranca;

public class Animal {
	String nome;
	String raca;
	String cor;
	String tamanho;
	



	
	

}
