package heranca;

public class AnimalDomesticado {

}
