package heranca;

public class Cachorro {

	public static void main(String[] args) {
		Animal cachorro = new Animal();
	}

}
