package heranca;

public class AnimalDeEstimacao extends Animal {
	
	public void brincar() {
		
	}
	
	public void tosar() {
		
	}
	
	public void passear() {
		
	}

}
