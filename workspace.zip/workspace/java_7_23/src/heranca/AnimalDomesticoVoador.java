package heranca;

public class AnimalDomesticoVoador {
	
	public void chocar() {
		
	}
	public void voar() {
	
}


}
