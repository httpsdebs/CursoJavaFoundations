package Aula_07;

import javax.swing.JOptionPane;

public class TioSam {

	public static void main(String[] args) {
		int nivel;
		
		nivel = Integer.parseInt(JOptionPane.showInputDialog("Digite o nível da mensalidade: "));
		
		if(nivel==1) {
			nivel_01();
		}else if(nivel==2) {
			nivel_02();
		}else if(nivel==3) {
			nivel_03();
		}else if(nivel==4) {
			nivel_04();
		}else{
			JOptionPane.showMessageDialog(null, "Não existente!");
		}
	}
	
	//======================fora do método main===================//
	
	public static void nivel_01(){
		int data = Integer.parseInt(JOptionPane.showInputDialog("Digite a data do pagamento: "));
		if(data==1) {
			double desconto = (51.50*15)/100;
			double total = 51.50 - desconto;
			JOptionPane.showMessageDialog(null, "Total a pagar: " + total);
		}else if(data>1 && data<=5) {
			double desconto = (51.50*10)/100;
			double total = 51.50 - desconto;
			JOptionPane.showMessageDialog(null, "Total a pagar: " + total);
		}else if(data>5 && data<=10) {
			double desconto = (51.50*3.89)/100;
			double total = 51.50 - desconto;
			JOptionPane.showMessageDialog(null, "Total a pagar: " + total);
		}else{
			JOptionPane.showMessageDialog(null, "Não existente!");
		}
	}
	
	public static void nivel_02(){
		int data = Integer.parseInt(JOptionPane.showInputDialog("Digite a data do pagamento: "));
		if(data==1) {
			double desconto = (65.00*15)/100;
			double total = 65.00 - desconto;
			JOptionPane.showMessageDialog(null, "Total a pagar: " + total);
		}else if(data>1 && data<=5) {
			double desconto = (65.00*10)/100;
			double total = 65.00 - desconto;
			JOptionPane.showMessageDialog(null, "Total a pagar: " + total);
		}else if(data>5 && data<=10) {
			double desconto = (65.00*3.89)/100;
			double total = 65.00 - desconto;
			JOptionPane.showMessageDialog(null, "Total a pagar: " + total);
		}else{
			JOptionPane.showMessageDialog(null, "Não existente!");
		}
	}
	
	public static void nivel_03(){
		int data = Integer.parseInt(JOptionPane.showInputDialog("Digite a data do pagamento: "));
		if(data==1) {
			double desconto = (65.00*15)/100;
			double total = 65.00 - desconto;
			JOptionPane.showMessageDialog(null, "Total a pagar: " + total);
		}else if(data>1 && data<=5) {
			double desconto = (65.00*10)/100;
			double total = 65.00 - desconto;
			JOptionPane.showMessageDialog(null, "Total a pagar: " + total);
		}else if(data>5 && data<=10) {
			double desconto = (65.00*3.89)/100;
			double total = 65.00 - desconto;
			JOptionPane.showMessageDialog(null, "Total a pagar: " + total);
			}else{
				JOptionPane.showMessageDialog(null, "Não existente!");
			}

		}public static void nivel_04(){
			int data = Integer.parseInt(JOptionPane.showInputDialog("Digite a data do pagamento: "));
			if(data==1) {
				double desconto = (80.00*15)/100;
				double total = 80.00 - desconto;
				JOptionPane.showMessageDialog(null, "Total a pagar: " + total);
			}else if(data>1 && data<=5) {
				double desconto = (80.00*10)/100;
				double total = 80.00 - desconto;
				JOptionPane.showMessageDialog(null, "Total a pagar: " + total);
			}else if(data>5 && data<=10) {
				double desconto = (80.00*3.89)/100;
				double total = 80.00 - desconto;
				JOptionPane.showMessageDialog(null, "Total a pagar: " + total);
				}else{
					JOptionPane.showMessageDialog(null, "Não existente!");
				}

			}
		
	}
	
