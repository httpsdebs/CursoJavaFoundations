package exercicios_02;

public class Exercicio_05 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
