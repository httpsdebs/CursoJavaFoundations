package exercicios_02;

import java.util.Scanner;

public class Exercicio_01 {

	public static void main(String[] args) {

		double produto;
		double desconto;
		double produtoReajustado;
		double valorDesconto;
		double total;
		
		Scanner ler= new Scanner(System.in);
		
		//entrada de dados
		System.out.println("digite o valor do produto");
		produto= ler.nextDouble();
		System.out.println("digite o valor do desconto");
		desconto=ler.nextDouble();
		
		//processamento de dados 
		valorDesconto= (produto/100)*desconto;
		produtoReajustado= produto-valorDesconto;
		total=produto-((produto/100)*desconto);
		
		//saída de dados
		
	System.out.println("O valor do desconto é:"+valorDesconto);
	System.out.println("O valor total de compra é:"+total);
		
		
	    
		
		
		
				
	}

}
