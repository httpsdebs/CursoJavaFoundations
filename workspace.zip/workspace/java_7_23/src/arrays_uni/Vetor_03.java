package arrays_uni;

import java.util.Scanner;

public class Vetor_03 {

	public static void main(String[] args) {

		Scanner ler = new Scanner(System.in);
		double media, notas, notaA=0;
		double []nota = new double[4];
		
		for (int i = 0; i < nota.length; i++) {
			System.out.println("Digite a nota");
			notas = ler.nextDouble();
			nota[i]=notas;
			notaA = notaA+nota[i];
		}
		for (int i = 0; i < nota.length; i++) {
			System.out.println("A nota da posiçao "+i+" é: "+nota[i]);
		}
		
		media = notaA/nota.length;
		System.out.println("A média é: "+media);
	}

}
