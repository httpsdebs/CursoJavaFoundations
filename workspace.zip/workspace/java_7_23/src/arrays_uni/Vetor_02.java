package arrays_uni;

import java.util.Scanner;

public class Vetor_02 {

	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
		String nome;
		String []nomes = new String[5];
		
		for (int i = 0; i < nomes.length; i++) {
			System.out.println("Digite um nome: ");
			nome = ler.nextLine();
			
			nomes[i] = nome;
		}
		
		for (int i = 0; i < nomes.length; i++) {
			System.out.println("O nome na posição " + i + " é: "+ nomes[i]);
		}
		
	}

}
