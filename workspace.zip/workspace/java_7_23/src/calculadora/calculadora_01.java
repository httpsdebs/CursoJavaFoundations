package calculadora;

import java.util.Scanner;

public class calculadora_01 {

	public static void main(String[] args) {
		
		
		String operacao;
		
		Scanner ler= new Scanner(System.in);
		
		System.out.println("Digite a operacao");
		operacao =ler.next();
		
		switch(operacao) {
		case"+":
			calculo.somar();
			break;
			
		default:
			break;
		
		}
	
		switch(operacao) {
		case"-":
			calculo.subtrair();
			break;
			
		default:
			break;
		
		}
	
		
		switch(operacao) {
		case"*":
			calculo.multiplicar();
			break;
			
		default:
			break;
		}
		
		
		
		switch(operacao) {
		case"/":
			calculo.dividir();
			break;
			
		default:
			break;
		}
		
		
		
		switch (operacao) {
		case "2*":
			calculo.exponenciar();
			break;

		default:
			break;
		}
		
		
	}

}
