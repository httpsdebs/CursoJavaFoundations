package calculadora;

import java.util.Scanner;

public class calculo {

      public static void somar() {

	int valor_01,valor_02,total;
	
	Scanner ler= new Scanner(System.in);
	
	System.out.println("Digite um valor");
	valor_01=ler.nextInt();
	
	System.out.println("Digite um valor");
	valor_02=ler.nextInt();
	
	total=valor_01+valor_02;
	System.out.println("O valor é:"+total);
	
      }

	


      
public static void subtrair() {

	int valor_01,valor_02,total;
	
	Scanner ler= new Scanner(System.in);
	
	System.out.println("Digite um valor");
	valor_01=ler.nextInt();
	
	System.out.println("Digite um valor");
	valor_02=ler.nextInt();
	
	total=valor_01-valor_02;
	System.out.println("O valor é:"+total);
	

}

public static void multiplicar() {

	int valor_01,valor_02,total;
	
	Scanner ler= new Scanner(System.in);
	
	System.out.println("Digite um valor");
	valor_01=ler.nextInt();
	
	System.out.println("Digite um valor");
	valor_02=ler.nextInt();
	
	total=valor_01*valor_02;
	System.out.println("O valor é:"+total);
	
}
	
public static void dividir() {
int valor_01,valor_02,total;
	
	Scanner ler= new Scanner(System.in);
	
	System.out.println("Digite um valor");
	valor_01=ler.nextInt();
	
	System.out.println("Digite um valor");
	valor_02=ler.nextInt();
	
	total=valor_01/valor_02;
	System.out.println("O valor é:"+total);
	
}

public static void exponenciar() {
double valor_01,valor_02,total;
	
	Scanner ler= new Scanner(System.in);
	
	System.out.println("Digite um valor");
	valor_01=ler.nextDouble();
	
	System.out.println("Digite um valor");
	valor_02=ler.nextDouble();
	
	total=Math.pow(valor_01,valor_02);
	System.out.println("O valor é:"+total);
}}
	
	
	
	
	
	
	
	
	
	
      






