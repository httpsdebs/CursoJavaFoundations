package Aula_09;

public class TrabalhandoStrings {

	public static void main(String[] args) {

		
		String texto = "Olá Mundo!";
		int tamanho;
		char primeiroChar;
		String subString;
		int indice;
		String maiusculo, minusculo, substituto;
		
		tamanho = texto.length();
		System.out.println("O tamanho do texto é: " + tamanho);
		
		primeiroChar = texto.charAt(0);
		System.out.println("O primeiro caracter é: " + primeiroChar);
		
		subString = texto.substring(5);
		System.out.println("A substring a partir do indice 5 é: " + subString);
		
		indice = texto.indexOf("mundo");
		System.out.println("A palavra mundo começa no índice: " + indice);
		
		minusculo = texto.toLowerCase();
		System.out.println("Em minúsculas: " + minusculo);
		
		maiusculo = texto.toUpperCase();
		System.out.println("Em maiuscúlas: " + maiusculo);
		
		substituto = texto.replace("Mundo","Amigo");
		System.out.println("Texto Mundo substituído por Amigo: " + substituto);
		
		String [] palavras = texto.split(" ");
		System.out.println("Palavras separadas por espaço: ");
		for(String palavra:palavras) {
			System.out.println(palavra);
		}

		boolean comecaComOla = texto.startsWith("Olá");
		System.out.println("O texto começa com: " + comecaComOla);

		boolean terminaComMundo = texto.endsWith("!");
		System.out.println("O texto termina com: " + terminaComMundo);

		boolean vazio = texto.isEmpty();
		System.out.println("Está vazio? " + vazio);

		
		String inverter = new StringBuilder(texto).reverse().toString();
		System.out.println("O texto invertido é: " + inverter);


		

	}

}
