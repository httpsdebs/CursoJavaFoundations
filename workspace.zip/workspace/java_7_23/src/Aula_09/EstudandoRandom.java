package Aula_09;

import java.util.Random;

public class EstudandoRandom {

	public static void main(String[] args) {

		Random random = new Random();
		
		int numeroInteiro = random.nextInt();
		System.out.println("Número Aleatório: " + numeroInteiro);
		
		int numeroInteiro1 = random.nextInt(40);
		System.out.println("Número Aleatório: " + numeroInteiro1);
		
		int numeroInteiro2 = random.nextInt(1,50);
		System.out.println("Número Aleatório: " + numeroInteiro2);
		
		
		double pontoFlutuante = random.nextDouble();
		System.out.println("Ponto Flutuante: " + pontoFlutuante);

		
	}

}
