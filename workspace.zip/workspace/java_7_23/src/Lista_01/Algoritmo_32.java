package Lista_01;

import javax.swing.JOptionPane;

public class Algoritmo_32 {

	public static void main(String[] args) {
		// Digite um número inteiro e imprimi-lo (o usuário deve digitar)
		
		String nome;
		
		nome = JOptionPane.showInputDialog("Digite o seu nome");
		JOptionPane.showMessageDialog(null,"Meu nome é " + nome );
	}

}
