package Lista_01;

public class Algoritmo_29 {

	public static void main(String[] args) {

		//Imprimir seu nome.
		
		System.out.println("Déborah Morales");
	}

}
