package Lista_01;

public class Algoritmo_28 {

	public static void main(String[] args) {

		//Imprimir a mensagem:"É PRECISO FAZER TODOS OS ALGORITMOS PARA APRENDER"
		
		System.out.println("É PRECISO FAZER TODOS OS ALGORITMOS PARA APRENDER");
	}

}
