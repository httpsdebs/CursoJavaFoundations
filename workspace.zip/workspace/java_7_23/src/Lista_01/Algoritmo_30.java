package Lista_01;

public class Algoritmo_30 {

	public static void main(String[] args) {
		//Criar um algoritmo que imprima o resultado da multiplicação entre 28 e 43.
		
		int valor1;
		int valor2;
		int resultado;
		
		valor1=28;
		valor2=43;
		resultado= valor1 * valor2;
		System.out.println("28 * 43 = "+ resultado);

	}

}
