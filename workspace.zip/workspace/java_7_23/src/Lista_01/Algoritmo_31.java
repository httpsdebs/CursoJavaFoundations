package Lista_01;

public class Algoritmo_31 {

	public static void main(String[] args) {
		//Criar um algoritmo que imprima a média entre os números 8, 9 e 7.
		
		int valor1=8;
		int valor2=9;
		int valor3=7;
		int resultado;
		
		resultado = valor1 + valor2 + valor3/3;
		
		System.out.println("A média de 8, 9 e 7 é " + resultado);
		
		
	}

}
