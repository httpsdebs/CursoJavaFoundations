package Aula_02;

import javax.swing.JOptionPane;

public class SaidaDeDados {

	public static void main(String[] args) {
		String nome="Déborah Morales";
		System.out.println(nome);
		JOptionPane.showMessageDialog(null,nome);

	}

}
