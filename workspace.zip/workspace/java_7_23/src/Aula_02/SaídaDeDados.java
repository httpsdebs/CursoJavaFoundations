package aula_02;

import javax.swing.JOptionPane;

public class SaídaDeDados {

	public static void main(String[] args) {

		String nome= "Deborah S";
		
		System.out.println(nome);
		JOptionPane.showMessageDialog(null, nome);
		
		
		
		
	}

}
