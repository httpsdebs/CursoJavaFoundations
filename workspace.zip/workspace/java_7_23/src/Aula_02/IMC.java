package aula_02;

import java.util.Scanner;

public class IMC {

	public static void main(String[] args) {
double peso;
double altura;
double imc;

Scanner ler = new Scanner(System.in);

//Entrada de dados 
System.out.println("Digite valor de Peso");
peso=ler.nextInt();
System.out.println("Digite valor de Altura");
altura = ler.nextInt();

		 
//Processando os dados
imc = peso/(altura*altura);


//Saída de dados do processamento 
System.out.println("O valor total é:"+imc);

		
		
		
	}

}
