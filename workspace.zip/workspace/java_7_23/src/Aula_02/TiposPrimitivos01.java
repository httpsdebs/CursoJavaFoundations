package Aula_02;

public class TiposPrimitivos01 {

	public static void main(String[] args) {

		byte exemplo01=127;
		short exemplo02=32_767;
		char exemplo03='F';
		int exemplo04=2_147_483_647;
		float exemplo05=2_000_000_000.90f;
		double exemplo06=2_000_000_000.90;
		long exemplo07=9_223_372_036_854_775_807l;
		boolean exemplo08=true;
		String exemplo09="890";  //recebe letra e começa com S maiusculo//
		//System.out.println(exemplo01);
		//System.out.println(exemplo02);
		//System.out.println(exemplo03);
		//System.out.println(exemplo04);
		//System.out.println(exemplo05);
		//System.out.println(exemplo06);
		//System.out.println(exemplo07);
		//System.out.println(exemplo08);
		//System.out.println(exemplo09);
		
		
		//exemplo04=exemplo01;
		//exemplo04=Integer.parseInt(exemplo09);
		//exemplo06=Double.parseDouble(exemplo09);

		
	}

}
