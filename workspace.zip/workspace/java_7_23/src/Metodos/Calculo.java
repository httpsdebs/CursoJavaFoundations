package Metodos;

import java.util.Scanner;

public class Calculo {
	
	double valor_01, valor_02,total;
	
	public Calculo() {
		super();
	}
	
	
	//=============salvando na memória===========//
	public Calculo(double valor_01, double valor_02, double total) {
		super();
		this.valor_01 = valor_01;
		this.valor_02 = valor_02;
		this.total = total;

	}
	
	void solicitarValor() {
		Scanner ler = new Scanner(System.in);
		System.out.println("Digite um valor: ");
		valor_01= ler.nextDouble();
		System.out.println("Digite outro valor");
		valor_02=ler.nextDouble();

	}
	
	void somar() {
		total= valor_01+valor_02;
		System.out.println("Total: " + total);
	}
	
	public static void subtrair(double valor1, double valor2) {
		double resultado;
		resultado=valor1-valor2;
		System.out.println("Total: " + resultado);

	}

}
