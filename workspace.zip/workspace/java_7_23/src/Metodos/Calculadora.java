package Metodos;

import java.util.Scanner;

public class Calculadora {

	public static void main(String[] args) {
		double valor_01, valor_02;

		Calculo calculadora = new Calculo();
		
		Scanner ler = new Scanner(System.in);
		System.out.println("Digite um valor: ");
		valor_01= ler.nextDouble();
		System.out.println("Digite outro valor");
		valor_02=ler.nextDouble();
		
		/*
		calculadora.solicitarValor();
		calculadora.somar();
		*/
		
		Calculo.subtrair(valor_01, valor_02);
	}

}
