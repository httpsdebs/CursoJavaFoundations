package Aula_10;

public class EstruturaRepeticao {

	public static void main(String[] args) {
		int i = 0;
		int total =0;
		
		while (i<=100) {
			total = 9*i;
			System.out.println("9 X " + i + " = " + total);
			i++;
		}
	}

}
