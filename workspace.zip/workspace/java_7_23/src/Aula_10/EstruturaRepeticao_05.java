package Aula_10;

public class EstruturaRepeticao_05 {

	public static void main(String[] args) {
		int contador;
		
		
		////////valor inicial // valor final // incremento //////////
		for (int contador = 0; contador < 10; contador++) {
			
			System.out.println("Essa é a volta: " + i);
			
		}

	}

}
