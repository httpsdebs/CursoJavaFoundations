package Aula_10;

public class EstruturaRepeticao_04 {

	public static void main(String[] args) {
		int i = 11;
		
		//==========ROTA==========//
	/*	do {
			System.out.println("Essa é a volta: " + i);
			i++;
		}while (i<10);
		*/
		
		
		//======Tática=====//
		while(i<10){
			System.out.println("Essa é a volta: " + i);
			i++;
		}
		
		

	}

}
