package Aula_10;

import java.util.Scanner;

public class EstruturaRepeticao_03 {

	public static void main(String[] args) {

		Scanner ler = new Scanner(System.in);
		
		int totalNotas = 0;
		int contador = 0;
		double media;
		
		while (true) {
			System.out.println("Digite a nota ou -1 para sair: ");
			int nota = ler.nextInt();
		
			if (nota ==-1) {
				break;
			}
			totalNotas = totalNotas + nota;
			contador++;
		}
		
		media = (double)totalNotas/contador;
		System.out.println("A média do aluno: " + media);
	}

}
