package Aula_01;

public class Aula_01B {

	public void abrirPorta() {

	System.out.println("Seja Bem Vindo ao mundo Java!");

	}
}
