package aula_01;

public class Aula01_A {
	
	public void abrirPorta() {
		
		
		
		System.out.println("Seja Bem vindo ao mundo Java");
		
		}
	}
	


