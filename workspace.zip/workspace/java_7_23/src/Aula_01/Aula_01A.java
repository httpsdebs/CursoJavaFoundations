package Aula_01;

public class Aula_01A {

	public static void main(String[] args) {
		Aula_01A oi = new Aula_01A();
		
		System.out.println("Olá Mundo");
		oi.abrirPorta();

	}

}
