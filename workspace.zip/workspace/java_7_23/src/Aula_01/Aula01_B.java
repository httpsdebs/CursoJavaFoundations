package aula_01;

public class Aula01_B {

	

	public static void main(String[] args) {
		Aula01_A oi = new Aula01_A();
		
		System.out.println("Ola Mundo");
		oi.abrirPorta();
		
		
	}

}
