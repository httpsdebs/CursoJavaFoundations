package Estrutura_Condicional;

public class Estrutura_Condicional02 {

	public static void main(String[] args) {
		int idade = 16;
		
		if(idade>=15 && idade<=18) {
			System.out.println("Aprovada");
		}else {
			System.out.println("Reprovada");
		}

	}

}
