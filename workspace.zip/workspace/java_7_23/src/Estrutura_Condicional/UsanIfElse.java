package Estrutura_Condicional;

public class UsanIfElse {

	public static void main(String[] args) {

		int idade=15;
		
		if (idade == 15) {
			System.out.println("Aprovada");
		}else {
			System.out.println("Reprovada");
		}
	}

}
