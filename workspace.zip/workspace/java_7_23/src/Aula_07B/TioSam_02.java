package Aula_07B;

import javax.swing.JOptionPane;

public class TioSam_02 {

	public static void main(String[] args) {
		int nivel;
		
		nivel = Integer.parseInt(JOptionPane.showInputDialog("Digite o nível da mensalidade: "));
		
		//usando o switch case
		
		switch(nivel) {
		case 1:
			CalcularMensalidade.nivel_01();
			break;
			
		case 2:
			CalcularMensalidade.nivel_02();
			break;
			
		case 3:
			CalcularMensalidade.nivel_03();
			break;
			
		case 4:
			CalcularMensalidade.nivel_01();
			break;
			
			default:
				JOptionPane.showMessageDialog(null, "Nível Inválido!");
				break;
		}
		
		
	}

}
