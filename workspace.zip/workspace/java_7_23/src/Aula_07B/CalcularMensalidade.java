package Aula_07B;

import javax.swing.JOptionPane;

public class CalcularMensalidade {

	public static void nivel_01(){
		int data = Integer.parseInt(JOptionPane.showInputDialog("Digite a data do pagamento: "));
		if(data==1) {
			double desconto = (51.50*15)/100;
			double total = 51.50 - desconto;
			JOptionPane.showMessageDialog(null, "Total a pagar: " + total);
		}else if(data>1 && data<=5) {
			double desconto = (51.50*10)/100;
			double total = 51.50 - desconto;
			JOptionPane.showMessageDialog(null, "Total a pagar: " + total);
		}else if(data>5 && data<=10) {
			double desconto = (51.50*3.89)/100;
			double total = 51.50 - desconto;
			JOptionPane.showMessageDialog(null, "Total a pagar: " + total);
		}else{
			JOptionPane.showMessageDialog(null, "Não existente!");
		}
	}
	
	public static void nivel_02(){
		int data = Integer.parseInt(JOptionPane.showInputDialog("Digite a data do pagamento: "));
		if(data==1) {
			double desconto = (65.00*15)/100;
			double total = 65.00 - desconto;
			JOptionPane.showMessageDialog(null, "Total a pagar: " + total);
		}else if(data>1 && data<=5) {
			double desconto = (65.00*10)/100;
			double total = 65.00 - desconto;
			JOptionPane.showMessageDialog(null, "Total a pagar: " + total);
		}else if(data>5 && data<=10) {
			double desconto = (65.00*3.89)/100;
			double total = 65.00 - desconto;
			JOptionPane.showMessageDialog(null, "Total a pagar: " + total);
		}else{
			JOptionPane.showMessageDialog(null, "Não existente!");
		}
	}
	
	public static void nivel_03(){
		int data = Integer.parseInt(JOptionPane.showInputDialog("Digite a data do pagamento: "));
		if(data==1) {
			double desconto = (65.00*15)/100;
			double total = 65.00 - desconto;
			JOptionPane.showMessageDialog(null, "Total a pagar: " + total);
		}else if(data>1 && data<=5) {
			double desconto = (65.00*10)/100;
			double total = 65.00 - desconto;
			JOptionPane.showMessageDialog(null, "Total a pagar: " + total);
		}else if(data>5 && data<=10) {
			double desconto = (65.00*3.89)/100;
			double total = 65.00 - desconto;
			JOptionPane.showMessageDialog(null, "Total a pagar: " + total);
			}else{
				JOptionPane.showMessageDialog(null, "Não existente!");
			}

		}public static void nivel_04(){
			int data = Integer.parseInt(JOptionPane.showInputDialog("Digite a data do pagamento: "));
			if(data==1) {
				double desconto = (80.00*15)/100;
				double total = 80.00 - desconto;
				JOptionPane.showMessageDialog(null, "Total a pagar: " + total);
			}else if(data>1 && data<=5) {
				double desconto = (80.00*10)/100;
				double total = 80.00 - desconto;
				JOptionPane.showMessageDialog(null, "Total a pagar: " + total);
			}else if(data>5 && data<=10) {
				double desconto = (80.00*3.89)/100;
				double total = 80.00 - desconto;
				JOptionPane.showMessageDialog(null, "Total a pagar: " + total);
				}else{
					JOptionPane.showMessageDialog(null, "Não existente!");
				}

			}
		
	}
	


