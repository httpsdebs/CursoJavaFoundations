package Revisão;

import javax.swing.JOptionPane;

public class Revisao_03 {

	public static void main(String[] args) {
	int codigo_01,codigo_02;
	double valorPeca_01,valorPeca_02;
	int  qtdePeca_01,qtdePeca_02;
	double ipi;
	

	codigo_01=Integer.parseInt(JOptionPane.showInputDialog("Digite o codigo das peças"));
	qtdePeca_01=Integer.parseInt(JOptionPane.showInputDialog("Digite a quantidade da peças"));
	valorPeca_01=Integer.parseInt(JOptionPane.showInputDialog("Digite o valor unitário da peça"));
	
	
	
	codigo_02=Integer.parseInt(JOptionPane.showInputDialog("Digite o código das peças"));
	qtdePeca_02=Integer.parseInt(JOptionPane.showInputDialog("Digite a quantidade de peças"));
	valorPeca_02=Integer.parseInt(JOptionPane.showInputDialog("Digite o valor unitário da peça"));
	
	ipi=Double.parseDouble(JOptionPane.showInputDialog("Digite a taxa de IPI"));
	
	
			
	
	
	
	
	

	}

}
