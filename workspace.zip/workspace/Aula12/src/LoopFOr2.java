
public class LoopFOr2 {
	public static void main(String[]args) {
	
	
	for (int hora = 0; hora <2 ; hora++) {
		for (int minutos = 0; minutos <60; minutos++) {
			for (int segundos = 0; segundos<60 ; segundos++) {
				
				System.out.println(hora+":"+minutos+":"+segundos);
			}
		}
	}
	
		
		
	}
}
