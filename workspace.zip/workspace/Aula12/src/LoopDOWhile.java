
public class LoopDOWhile {
	public static void main(String[]args) {
		
	int i= 11;
	

	
	while (i<=10) {
		
		System.out.println("Essa é a volta: "+i);
		i++;
		
	}
		
		
		
		
		
	}
}
