

public class Loop {

	public static void main(String[]args) {
		
		int i =0;
		int total=0;
		
		
		while(i<=10) {
			total=9*i;
			System.out.println("9 X "+i+" = "+total);
			i++;
		}
		
		
	
		
		
	}
	
}
