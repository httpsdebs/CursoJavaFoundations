
public class LoopFOr {
	public static void main(String[]args) {
		
		int contador;
		
		for(contador=0;contador<10;contador++) {
			
			System.out.println("Essa é a volta "+contador);
		}
		
		
	}
}
